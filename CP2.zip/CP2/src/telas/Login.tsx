import { Button, Text } from "@rneui/base";
import { TextInput, View,StyleSheet } from "react-native";
import { useState, } from "react";


export default props =>{
    const[usuario,setUsario]=useState(props.route.params?props.route.params:{})
    //console.log(Object.keys(props.route.params))

    return(
        <View style={{gap:15}}>
            <Text>Nome</Text>
            <TextInput 
                placeholder="Nome de Usuario"
                style={estilo.input}
                value={usuario.nome}
            /><Text>Senha</Text>
            <TextInput 
                placeholder="Senha"
                style={estilo.input}
                value={usuario.nome}
            />
            <Button> Avancar </Button>
        </View>
        
        
    )
}

const estilo = StyleSheet.create({
    input:{
        borderWidth:1,
        borderRadius:5,
        width:250,
        height:40
    }
})