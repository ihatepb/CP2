export default [
    {
        id:1,
        nome:'Fernando',
        email:'fernando@gmail.com',
        fotoPerfil:'https://img.freepik.com/free-psd/3d-illustration-person-with-sunglasses_23-2149436188.jpg?w=740&t=st=1712264569~exp=1712265169~hmac=6c546d932f4ed80bc16a99bd367e0046852fdf3f230ab7042a810924d84666cd'
    },
    {
        id:2,
        nome:'João',
        email:'joao@gmail.com',
        fotoPerfil:'https://img.freepik.com/free-psd/3d-illustration-person-with-sunglasses_23-2149436188.jpg?w=740&t=st=1712264569~exp=1712265169~hmac=6c546d932f4ed80bc16a99bd367e0046852fdf3f230ab7042a810924d84666cd'
    }

]